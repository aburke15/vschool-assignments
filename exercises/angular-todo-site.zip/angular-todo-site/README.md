Exercise requirements
=====================

You will have a form that allows the user to add new todos

Each todo will have a checkbox where it can be marked complete or incomplete

If a todo item is complete, it should have a strikethrough line on it

A user should be able to delete a Todo item

A user should be able to edit/update the todo item

A user should be able to attach an imgUrl to the item 

(and the img should show if there is an imgUrl)

A user should be able to give the item a price

A user should be able to give the item a description

Website should be nicely laid out with Bootstrap